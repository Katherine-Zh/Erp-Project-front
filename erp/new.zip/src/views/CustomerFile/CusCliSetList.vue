<template>
  <a-card :bordered="false">
    <!-- 操作按钮区域 -->
    <div class="table-operator">
      <a-button @click="handleAdd" type="primary" icon="plus">新建</a-button>
      <a-dropdown v-if="selectedRowKeys.length > 0">
        <a-menu slot="overlay">
          <a-menu-item key="1" @click="batchDel"><a-icon type="delete"/>删除</a-menu-item>
        </a-menu>
        <a-button style="margin-left: 8px"> 批量操作 <a-icon type="down" /></a-button>
      </a-dropdown>
    </div>

    <!-- table区域-begin -->
    <div>

      <a-table
        ref="table"
        size="middle"
        bordered
        rowKey="id"
        :columns="columns"
        :dataSource="dataSource"
        :pagination="ipagination"
        :loading="loading"
        :rowSelection="{selectedRowKeys: selectedRowKeys, onChange: onSelectChange}"
        class="j-table-force-nowrap"
        @change="handleTableChange">

        <template slot="htmlSlot" slot-scope="text">
          <div v-html="text"></div>
        </template>
        <template slot="imgSlot" slot-scope="text">
          <span v-if="!text" style="font-size: 12px;font-style: italic;">无图片</span>
          <img v-else :src="getImgView(text)" height="25px" alt="" style="max-width:80px;font-size: 12px;font-style: italic;"/>
        </template>
        <template slot="fileSlot" slot-scope="text">
          <span v-if="!text" style="font-size: 12px;font-style: italic;">无文件</span>
          <a-button
            v-else
            :ghost="true"
            type="primary"
            icon="download"
            size="small"
            @click="uploadFile(text)">
            下载
          </a-button>
        </template>
       <span slot="action" slot-scope="text, record">
          <a @click="handleOpen(record)">用户</a>
<!--          handleEdit(record)-->

          <a-divider type="vertical" />
          <a-dropdown>
            <a class="ant-dropdown-link">更多 <a-icon type="down" /></a>
           <a-menu slot="overlay">
                <a-menu-item>
                  <a @click="handlePerssion(record.id)">权限</a>
                </a-menu-item>
                <a-menu-item>
                  <a @click="handleEdit(record)">编辑</a>
                </a-menu-item>
                <a-menu-item>
                  <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete1(record.id)">
                    <a>删除</a>
                  </a-popconfirm>
                </a-menu-item>
              </a-menu>
          </a-dropdown>
        </span>

      </a-table>
    </div>

    <ywFobWare-modal ref="modalForm" @ok="modalFormOk"></ywFobWare-modal>
  </a-card>
</template>

<script>

  import '@/assets/less/TableExpand.less'
  import { mixinDevice } from '@/utils/mixin'
  import { JeecgListMixin } from '@/mixins/JeecgListMixin'

  import {filterMultiDictText} from '@/components/dict/JDictSelectUtil'
  import JDate from '@/components/jeecg/JDate'
  import JDictSelectTag from "@/components/dict/JDictSelectTag"
  import JMultiSelectTag from "@/components/dict/JMultiSelectTag"

  export default {
    name: "CliCliSetDet1",
    mixins:[JeecgListMixin, mixinDevice],
    components: {
      filterMultiDictText,
      JDate,
      JDictSelectTag,
      JMultiSelectTag,
    },
    data () {
      return {
        description: '客户委托人设置明细',
        // 表头
        columns: [
          {
            title:'委托人',
            align:"center",
            dataIndex: 'client'
          },
          {
            title:'一级分类',
            align:"center",
            dataIndex: 'firstClassCode'
          },
          {
            title:'类别编码',
            align:"center",
            dataIndex: 'classCode'
          },
          {
            title:'类别名称',
            align:"center",
            dataIndex: 'className'
          },
          {
            title:'商品编码',
            align:"center",
            dataIndex: 'wareId'
          },
          {
            title:'通用名称',
            align:"center",
            dataIndex: 'commonName'
          },
          {
            title:'商品规格',
            align:"center",
            dataIndex: 'wareSpeci'
          },
          {
             title:'生产企业名称',
            align:"center",
             dataIndex: 'manufacture'
           },
           {
             title:'商品单位',
            align:"center",
             dataIndex: 'wareUnit'
           },
          {
            title:'备注',
            align:"center",
            dataIndex: 'notes'
          },
          {
            title:'创建人',
            align:"center",
            dataIndex: 'createBy'
          },
          {
            title:'创建时间',
            align:"center",
            dataIndex: 'createTime'
          },
          {
            title:'最终修改人',
            align:"center",
            dataIndex: 'updateBy'
          },
          {
            title:'最终修改时间',
            align:"center",
            dataIndex: 'updateTime'
          },
          {
            title: '操作',
            dataIndex: 'action',
            align:"center",
            width:147,
            scopedSlots: { customRender: 'action' }
          },
        ],
        url: {
          add:"/yw_customclientware/ywCustomClientWare/add",
          list: "/ywwareinfo/ywWareInfo/list",
          delete: "/yw_customclientware/ywCustomClientWare/delete",
          deleteBatch: "/yw_customclientware/ywCustomClientWare/deleteBatch",
          edit:"/yw_customclientware/ywCustomClientWare/edit",
          exportXlsUrl: "/ywfobware/ywFobWare/exportXls",
          importExcelUrl: "ywfobware/ywFobWare/importExcel",
          changeFormal : "/ywfobware/ywFobWare/changeFormal",
        },
        sta:1 ,
        dictOptions:{},
      }
    },
    computed: {
      importExcelUrl: function(){
        return `${window._CONFIG['domianURL']}/${this.url.importExcelUrl}`;
      },
    },
    methods: {
      initDictConfig(){
      }
    }
  }
</script>
<style scoped>
  @import '~@assets/less/common.less';
</style>