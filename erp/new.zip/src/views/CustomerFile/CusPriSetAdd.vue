<template xmlns:a-col="http://www.w3.org/1999/html">
  <div style="background-color: white">
    <a-spin :spinning="confirmLoading">
      <a-form id="ddd" :form="form" >
        <p align="left" style="font-size:20px">
           <b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;新建打印方式</b>
        </p>  
        <a-divider/>        
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px;">单据名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag type="list"  v-decorator="['documentName', validatorRules.documentName]" :trigger-change="true"  />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px;">客户编码</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input disabled="true" v-decorator="['customId', validatorRules.customId]"  ></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px;color:red">客户名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag  type="list"  v-decorator="['customName', validatorRules.customName]" :trigger-change="true"  />
            </a-form-item>
          </a-col>
        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px">子结算户编码</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input disabled="true" v-decorator="['subProjectCode', validatorRules.subProjectCode]"  ></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">子结算户名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag  type="list"  v-decorator="['subProjectName', validatorRules.subProjectName]" :trigger-change="true" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">仓库</p>
            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['storehouse', validatorRules.storehouse]"  ></a-input>
              
            </a-form-item>
          </a-col>
        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px;color: red">打印方案号</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['printTypeId', validatorRules.printTypeId]"  ></a-input>
             
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">打印方案名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['printTypeName', validatorRules.printTypeName]"  ></a-input>
          
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px;color: red">打印机名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag type="list"  v-decorator="['printerName', validatorRules.printerName]" :trigger-change="true" />
            </a-form-item>
          </a-col>
        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px">打印次数</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
               <a-input  v-decorator="['printNums', validatorRules.printNums]"  ></a-input>
              
            </a-form-item>
        </a-col>

       </a-row> 


        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col style="float: right ;overflow: hidden;" class="table-page-search-submitButtons">
              <span>
                <a-button @click="handReturn" style="margin-right: 8px">
                  取消
                </a-button>
                <!-- <a-button type="primary" @click="Reset" style="margin-right: 8px"> -->
                <a-button @click="handReturn" style="margin-right: 8px">    
                 重置
                </a-button>
                <a-button type="primary" html-type="submit" @click="handleOk" style="margin-right: 16px">
                 确定
                </a-button>
              </span>
          </a-col>
        </a-row>
      </a-form>
    </a-spin>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  </div>
</template>

<script>

  import { httpAction } from '@/api/manage'
  import pick from 'lodash.pick'
  import { validateDuplicateValue } from '@/utils/util'
  import JDate from '@/components/jeecg/JDate'

  import JDictSelectTag from "@/components/dict/JDictSelectTag"
  import JMultiSelectTag from "@/components/dict/JMultiSelectTag"



  export default {
    name: "客户打印设置新建",
    components: {
      JDate,
      JDictSelectTag,
      JMultiSelectTag,
    },
    data () {
      return {

        form: this.$form.createForm(this),
        title:"操作",
        width:800,
        visible: false,
        model: {},
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },

        confirmLoading: false,
        validatorRules: {
         customName: {
            rules: [
              { required: false, message: '单据名称!'},
            ]
          },

          customId: {
            rules: [
              { required: false, message: '客户编码!'},
            ]
          },
          customName: {
            rules: [
              { required: true, message: '客户名称!'},
            ]
          },
          subProjectCode: {
            rules: [
              { required: false, message: '子结算户编码!'},
            ]
          },
          subProjectName: {
            rules: [
              { required: false, message: '子结算户名称!'},
            ]
          },
          storehouse: {
            rules: [
              { required: false, message: '仓库!'},
            ]
          },
          printTypeId: {
            rules: [
              { required: true, message: '打印方案号!'},
            ]
          },
          printTypeName: {
            rules: [
              { required: false, message: '打印方案名称!'},
            ]
          },
          printerName: {
            rules: [
              { required: true, message: '打印机名称!'},
            ]
          },
          printNums: {
            rules: [
              { required: false, message: '打印机次数!'},
            ]
          },

        },
        url: {
          add:"/yw_customprinttype/ywCustomPrintType/add",
          delete:"/yw_customprinttype/ywCustomPrintType/delete",
          deleteBatch:"/yw_customprinttype/ywCustomPrintType/deleteBatch",
          edit:"/yw_customprinttype/ywCustomPrintType/edit",
          list:"/yw_customprinttype/ywCustomPrintType/list",
          queryById:"/yw_customprinttype/ywCustomPrintType/queryById",
        }
      }
    },
    created () {

    },
    mounted () {

      this.edit()


    },
    methods: {
      add () {

      },
 

      edit () {
        this.form.resetFields();
        this.model = Object.assign({},this.$route.query);
        this.visible = true;
        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.model,'customName','customId','customName','subProjectCode','subProjectName','storehouse','printTypeId','printTypeName','printerName','printNums'))
        })
      },

      handSubmit(){

        const that = this;
        console.log("=======jjjjjjj")
        // 触发表单验证
        this.form.validateFields((err, values) => {
          if (!err) {
            that.confirmLoading = true;
            let httpurl = '';
            let method = '';

            httpurl+=this.url.edit;
            method = 'put';

            let formData = Object.assign(this.model, values);
            console.log("表单提交数据",formData)
            httpAction(httpurl,formData,method).then((res)=>{
              if(res.success){
                that.$message.success(res.message);

              }else{
                that.$message.warning(res.message);
              }
            }).finally(() => {
              that.confirmLoading = false;

            })
          }
        })
      },

      popupCallback(row){
        this.form.setFieldsValue(pick(row,'customName','customId','customName','subProjectCode','subProjectName','storehouse','printTypeId','printTypeName','printerName','printNums'))
      },


    }
  }
</script>