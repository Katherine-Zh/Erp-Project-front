<template xmlns:a-col="http://www.w3.org/1999/html">
  <div style="background-color: white">
    <a-spin :spinning="confirmLoading">
      <a-form id="ddd" :form="form" >
        <p align="left" style="font-size:20px">
           <b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;新建客户档案_金税用</b>
        </p>  
        <a-divider/>        
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px;">客户编码</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input disabled="true" v-decorator="['customId', validatorRules.customId]"  ></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px;color:red">客户名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag  type="list"  v-decorator="['customName', validatorRules.customName]" :trigger-change="true"/>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px;">子结算户编码</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input disabled="true" v-decorator="['subProjectCode', validatorRules.subProjectCode]"  ></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px;color:red">子结算户名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag   type="list"  v-decorator="['subProjectName', validatorRules.subProjectName]" :trigger-change="true"  />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">税号</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['taxNum', validatorRules.taxNum]"  ></a-input>
              
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">电话</p>
            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['telephone', validatorRules.telephone]"  ></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="16">
            <p style="margin-bottom: 0px">地址</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['address', validatorRules.address]"  ></a-input>
              
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <p style="margin-bottom: 0px">银行名称</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['bankName', validatorRules.bankName]"  ></a-input>
              
            </a-form-item>
          </a-col>

        </a-row>
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px">银行账号</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['bankAccount', validatorRules.bankAccount]"  ></a-input>
              
            </a-form-item>
        </a-col>
       
      
          <a-col :span="8">
            <p style="margin-bottom: 0px">邮件</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
             <a-input  v-decorator="['email', validatorRules.email]"  ></a-input>
              
            </a-form-item>
        </a-col>
         
        
          <a-col :span="8">
            <p style="margin-bottom: 0px">销售最低限额</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <a-input  v-decorator="['lowestSale', validatorRules.lowestSale]"  ></a-input>
              
            </a-form-item>

          </a-col>
        </a-row>  
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col :span="8">
            <p style="margin-bottom: 0px">开具类型</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              <j-dict-select-tag  type="list"  v-decorator="['openType', validatorRules.openType]" :trigger-change="true"  />
            </a-form-item>
        </a-col>
       
          
      
          <a-col :span="8">
            <p style="margin-bottom: 0px">备注</p>
            <a-form-item  :labelCol="labelCol" :wrapperCol="wrapperCol">
              
             <a-input  v-decorator="['notes', validatorRules.notes]"  ></a-input>
            </a-form-item>
         </a-col>
        </a-row>
       
   

      
        <a-row justify="center" style="margin-left: 120px" :gutter="[{ xs: 8, sm: 16, md: 24},{ xs: 8, sm: 16, md: 24}]">
          <a-col style="float: right ;overflow: hidden;" class="table-page-search-submitButtons">
              <span>
                <a-button @click="handReturn" style="margin-right: 8px">
                  取消
                </a-button>
                <!-- <a-button type="primary" @click="Reset" style="margin-right: 8px"> -->
                <a-button @click="handReturn" style="margin-right: 8px">    
                 重置
                </a-button>
                <a-button type="primary" html-type="submit" @click="handleOk" style="margin-right: 16px">
                 确定
                </a-button>
              </span>
          </a-col>
        </a-row>
      </a-form>
    </a-spin>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  </div>
</template>

<script>

  import { httpAction } from '@/api/manage'
  import pick from 'lodash.pick'
  import { validateDuplicateValue } from '@/utils/util'
  import JDate from '@/components/jeecg/JDate'

  import JDictSelectTag from "@/components/dict/JDictSelectTag"
  import JMultiSelectTag from "@/components/dict/JMultiSelectTag"



  export default {
    name: "UserInfEdit",
    components: {
      JDate,
      JDictSelectTag,
      JMultiSelectTag,
    },
    data () {
      return {
      // 客户档案金税新建
        form: this.$form.createForm(this),
        title:"操作",
        width:800,
        visible: false,
        model: {},
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },

        confirmLoading: false,
        validatorRules: {
          customId: {
            rules: [
              { required: false, message: '客户编码!'},
            ]
          },

          customName: {
            rules: [
              { required: true, message: '客户名称!'},
            ]
          },
          subProjectCode: {
            rules: [
              { required: false, message: '子结算户编码!'},
            ]
          },
          subProjectName: {
            rules: [
              { required: true, message: '子结算户名称!'},
            ]
          },          
          taxNum: {
            rules: [
              { required: false, message: '税号!'},
            ]
          },
          telephone: {
            rules: [
              { required: false, message: '电话!'},
            ]
          },
          address: {
            rules: [
              { required: false, message: '地址!'},
            ]
          },
          bankName: {
            rules: [
              { required: false, message: '银行名称!'},
            ]
          },
          bankAccount: {
            rules: [
              { required: false, message: '银行账户!'},
            ]
          },
          email: {
            rules: [
              { required: false, message: '邮件!'},
            ]
          },
          lowestSale: {
            rules: [
              { required: false, message: '销售最低限额!'},
            ]
          },
          openType: {
            rules: [
              { required: false, message: '开具类型!'},
            ]
          },
         notes: {
             rules: [
               { required: false, message: '备注!'},
             ]
           },
       
        },
        url: {
          add: "/yw_customcashtax/ywCustomCashTax/add",
          queryById:"/yw_customcashtax/ywCustomCashTax/queryById",
          edit: "/yw_customcashtax/ywCustomCashTax/edit",
          delete:"/yw_customcashtax/ywCustomCashTax/delete",
         deleteBatch:"/yw_customcashtax/ywCustomCashTax/deleteBatch",
         list:"/yw_customcashtax/ywCustomCashTax/list",
        }
      }
    },
    created () {

    },
    mounted () {

      this.edit()


    },
    methods: {
      add () {

      },
   
      edit () {
        this.form.resetFields();
        this.model = Object.assign({},this.$route.query);
        this.visible = true;
        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.model,'customId','customName','subProjectCode','subProjectName','taxNum','telephone','address','bankName','bankAccount','email','lowestSale','openType','notes'))
        })
      },

      handSubmit(){

        const that = this;
        console.log("=======jjjjjjj")
        // 触发表单验证
        this.form.validateFields((err, values) => {
          if (!err) {
            that.confirmLoading = true;
            let httpurl = '';
            let method = '';

            httpurl+=this.url.edit;
            method = 'put';

            let formData = Object.assign(this.model, values);
            console.log("表单提交数据",formData)
            httpAction(httpurl,formData,method).then((res)=>{
              if(res.success){
                that.$message.success(res.message);

              }else{
                that.$message.warning(res.message);
              }
            }).finally(() => {
              that.confirmLoading = false;

            })
          }
        })
      },

      popupCallback(row){
        this.form.setFieldsValue(pick(row,'customId','customName','subProjectCode','subProjectName','taxNum','telephone','address','bankName','bankAccount','email','lowestSale','openType','notes'))
      },


    }
  }
</script>