import AppPage from './App'
import ArticlePage from './Article'
import ProjectPage from './Project'
import WxboundPage from './Wxbound'

export { AppPage, ArticlePage, ProjectPage, WxboundPage }